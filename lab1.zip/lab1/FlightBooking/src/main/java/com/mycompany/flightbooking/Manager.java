/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.flightbooking;

import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author azman
 */
public class Manager{
    ArrayList<Flight> flights = new ArrayList<>();
    ArrayList<Ticket> tickets = new ArrayList<>();  
    
    public void createFlights(){
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Please input the starting point:");
        String og = sc.nextLine();
        
        System.out.println("Please input the destination:");
        String ds = sc.nextLine();
        
        System.out.println("Please input the departure time:");
        String dt = sc.nextLine();
        
        System.out.println("Please input the flight number:");
        int fn = sc.nextInt();
        
        System.out.println("Please input the capacity:");
        int c = sc.nextInt();
        
        System.out.println("Please input the original price:");
        double op = sc.nextDouble();

        flights.add(new Flight(fn, c, og, ds, dt, op));
    }
    
    public void displayAvailableFlights(String origin, String destination){
        for(int i = 0; i < flights.size(); i++){
            if(flights.get(i).getOrigin().equals(origin) && flights.get(i).getDestination().equals(destination)){
                if(flights.get(i).getNumberOfSeatsLeft() > 0)
                    System.out.println(flights.get(i));
            }
        }
    }
    
    public Flight getFlight(int fn){
        for(int i = 0; i < flights.size(); i++){
            if(flights.get(i).getFlightNumber()== fn){
                return(flights.get(i));
            }
            else
                return null;
        }
        return null;
    }
    
    public void bookSeat(int flightNumber, Passenger passenger){
        double dsPr;
        if (getFlight(flightNumber)== null)
            System.out.println("This flight is not available.\n");
        
        else{
            Flight flight =getFlight(flightNumber);
            if (flight.bookASeat()== true){
                dsPr= passenger.applyDiscount(flight.getOriginalPrice());
                tickets.add(new Ticket(passenger,flight,dsPr));
            }
            else
            System.out.println("Sorry, this Flight is fully booked.\n");
        }
    }
    
    public static void main(String[] args){
        Passenger passenger = new Member ("Bill", 45, 8);
        Passenger passenger2 = new Member ("Thomas", 47, 4);
        Passenger passenger3 = new NonMember ("Harry", 14);
        Passenger passenger4 = new NonMember ("Lisa", 20);
        
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Please input the number of flights you want to add:");
        int i = sc.nextInt();
        
        
        Manager m1 = new Manager();
        Manager m2 = new Manager();
                
        for(int j = 0; j < i; j++){
            System.out.println("--------------------------------------------\n");
            m1.createFlights();
                   
        }
        
        m1.displayAvailableFlights("Toronto", "London");
        System.out.println("\ngetFlight: " + m1.getFlight(119) + "\n");
                     
        m1.bookSeat(119, passenger);
        m1.bookSeat(119, passenger2);
        m1.bookSeat(119, passenger3);
        m1.bookSeat(119, passenger4);
        
        System.out.println("******TICKETS PRINTING*******");
        System.out.println("\nTicket: " + m1.tickets.get(0));
        System.out.println("\nTicket: " + m1.tickets.get(1));  
        System.out.println("\nTicket: " + m1.tickets.get(2));
        System.out.println("\nTicket: " + m1.tickets.get(3));
        
    }
}
