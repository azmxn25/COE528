/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.flightbooking;

import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author azman
 */
public class FlightTest {
    
    public FlightTest() {
    }
    
    @BeforeEach
    public void setUp() {
        Flight flightTest = new Flight(1000,5, "Toronto", "Dhaka", "1/30/24 10 AM", 850.0);
    }
    
    @Test
    public void testConstructor(){
        boolean matching = true;
        try{
            Flight flightTest2 = new Flight(1000,5, "Toronto", "Dhaka", "1/30/24 10 AM", 850.0);
        }
        catch (IllegalArgumentException e){
            matching = false;
        }
        assertTrue(matching);
    }
    
    
    @Test
    public void testInvalidConstructor(){
        boolean matching = false;
        try{
            Flight flightTest2 = new Flight(9999, 5, "Toronto", "Dhaka", "1/30/24 10 AM", 850);
        }
        catch(IllegalArgumentException e){
            matching = true;
        }
        assertTrue(matching);
    }
    
    @Test
    public void testSettersandGetters(){
        Flight flightTest4 = new Flight(5555, 5, "Toronto", "Dhaka", "1/30/24 10 AM", 850);
        
        flightTest4.setFlightNumber(4876);
        assertEquals(4876, flightTest4.getFlightNumber());
        
        flightTest4.setOrigin("Montreal");
        assertEquals("Montreal", flightTest4.getOrigin());
        
        flightTest4.setDestination("New York");
        assertEquals("New York", flightTest4.getDestination());
        
        flightTest4.setDepartureTime("8 AM");
        assertEquals("8 AM", flightTest4.getDepartureTime());
        
        flightTest4.setCapacity(300);
        assertEquals(300, flightTest4.getCapacity());
        
        flightTest4.setNumberOfSeatsLeft(250);
        assertEquals(250, flightTest4.getNumberOfSeatsLeft());
        
        flightTest4.setOriginalPrice(1500);
        assertEquals(1500, flightTest4.getOriginalPrice(), 0.01);        
    }
    
    /**
     * Test of bookASeat method, of class Flight.
     */
    @Test
    public void testBookASeat() {
        Flight flightTest5 = new Flight(117, 500, "London", "Dubai", "1/29/24 1 PM", 500);
        
        assertTrue(flightTest5.bookASeat());
        assertEquals(3, flightTest5.getNumberOfSeatsLeft());
        
        assertTrue(flightTest5.bookASeat());
        assertEquals(2, flightTest5.getNumberOfSeatsLeft());
        
        assertTrue(flightTest5.bookASeat());
        assertEquals(1, flightTest5.getNumberOfSeatsLeft());
        
        assertFalse(flightTest5.bookASeat());
        assertEquals(0, flightTest5.getNumberOfSeatsLeft());
    }

    /**
     * Test of toString method, of class Flight.
     */
    @Test
    public void testToString() {
        Flight flightTest6 = new Flight(117, 500, "London", "Dubai", "1/29/24 1 PM", 500);
        
        assertEquals("Flight 119, Toronto to Lisbon, 10 PM, Original Price: $400.00", flightTest6.toString());
    }
    
}
