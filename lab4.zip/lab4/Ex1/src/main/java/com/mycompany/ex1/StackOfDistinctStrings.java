/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex1;
import java.util.ArrayList;

/**
 *
 * @author azman
 */
public class StackOfDistinctStrings {
// Overview: StacksOfDistinctStrings are mutable, bounded
// collection of distinct strings that operate in
// LIFO (Last-In-First-Out) order.
//
// The abstraction function is:
// a) Write the abstraction function here
// The AF is: AF(x)= a stack s such that { "x.items.get(i)",  for all 0 <= i < items x.items.size() } with the top = x.items.get(items.size() - 1) and bottom = x.items.get(0)
//
//
//
// The rep invariant is:
// b) Write the rep invariant here
// x.items.get(i) != x.items.get(j) for all 0 <= i < j < x.items.size() (no repeating items in the stack)
// x.items.get(k) != null for all 0 <= k < x.items.size (no null strings in the stack)
//
//
//the rep
private ArrayList<String> items;
// constructor
public StackOfDistinctStrings() {
// EFFECTS: Creates a new StackOfDistinctStrings object
items = new ArrayList<String>();
}
public void push(String element) throws Exception {
// MODIFIES: this
// EFFECTS: Appends the element at the top of the stack
// if the element is not in the stack, otherwise
// does nothing.
    if(element == null) throw new Exception();
    if(false == items.contains(element))
    items.add(element);
}
public String pop() throws Exception {
// MODIFIES: this
// EFFECTS: Removes an element from the top of the stack
    if (items.size() == 0) throw new Exception();
    return items.remove(items.size()-1);
}
public boolean repOK() {
// EFFECTS: Returns true if the rep invariant holds for this
// object; otherwise returns false
// c) Write the code for the repOK() here
    for(int i = 0; i<items.size(); i++){
        if(items.get(i)== null){
            return false;    
        }
        for(int j = i + 1; j<items.size(); j++){
            if (items.get(i).equals(items.get(j))){
                return false;                  
            }
        }
    }
    return true;
}
@Override
public String toString() {
// EFFECTS: Returns a string that contains the strings in the
// stack and the top element. Implements the
// abstraction function.
// d) Write the code for the toString() here
    if(items.size() == 0){
        return "{}";
    }
    String returnStack = "{";
    for(int i = 0; i<items.size() - 1; i++){
      returnStack = returnStack + "\"" + items.get(i) + "\"" + ", ";
    }
    
    returnStack = returnStack + "\"" + items.get(items.size() - 1) + "\"" + "} The top is " + items.get(items.size() - 1);
    return returnStack;
}
public static void main(String[] args) throws Exception { //just for testing
        StackOfDistinctStrings a = new StackOfDistinctStrings();
         StackOfDistinctStrings b = new StackOfDistinctStrings();
        a.push("apple");
        a.push("pineapple");
        a.push("pen");
        a.push("FreeMarks");
        System.out.println("Before pop " + a);
        System.out.println("Popping: " +  a.pop());
        System.out.println(a);
        System.out.println(a.repOK()); //true 
        a.items.set(1, "apple"); //sets 2nd element to be apple as well, to check repOk
        System.out.println(a);
        System.out.println(a.repOK()); //repOk is false cause there are multiple of same item 
        System.out.println(b);
    }
}
