/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex1;
import java.util.ArrayList;

/**
 *
 * @author azman
 */
public class Queue<T> {
// Overview: Queue are mutable, bounded
// collection of elements that operate in
// FIFO (First-In-First-Out) order.
//
// The abstraction function is:
// a) Write the abstraction function here
//The AF is: AF(x) = a queue such that the elements of the queue are x.elements.get(i) for all 0 <= i < x.elements.size(), 
//and the first in the queue is x.elements.get(0) and last in queue is x.elements.get(x.elements.size() - 1)
//
//
// The rep invariant is:
// b) Write the rep invariant here
//x.elements.get(k) != null for all 0 <= k < x.elements.size() (no null elements in the queue)
//
//
//
//the rep
    private ArrayList<T> count;

    // constructor
    public Queue() {
    // EFFECTS: Creates a new Queue object that is empty
        count = new ArrayList<>();
    }

    public void enqueue(T element) throws Exception {
// MODIFIES: this
// EFFECTS: Appends the element at the end of the queue
// if the element is not null, otherwise
// does nothing.
        if(element == null) throw new Exception();
        count.add(element);
    }
    
    public T dequeue() throws Exception {
// MODIFIES: this
// EFFECTS: Removes an element from the front of the queue
        if (count.size() == 0) throw new Exception();
        return count.remove(0);
    }

    public boolean repOK() {
// EFFECTS: Returns true if the rep invariant holds for this
// object; otherwise returns false
// c) Write the code for the repOK() here
        for(T element : count){
            if(element == null){
                return false;
            }
        }
        return true;
    }

    public boolean isEmpty() {
        return count.size() == 0;
    }

    

@Override
    public String toString() {
// EFFECTS: Returns a string that contains the rep of the
// queue and the first and last elements. Implements the
// abstraction function.
    if (count.size() == 0) return "{}"; //empty queue 
    String returnMessage = "{";
    for (int i = 0; i < count.size() - 1; i++) {
        returnMessage = returnMessage + "\"" + count.get(i) + "\"" + ", ";
    }
    returnMessage = returnMessage + "\"" + count.get(count.size() - 1) + "\"" + "} The front of the queue is " + count.get(0) + ", and the rear of the queue is " + count.get(count.size() - 1)  ;
    return returnMessage;
    
    }

public static void main(String [] args) throws Exception { //main method 
        // Test the queue implementation
        Queue<Integer> queue = new Queue<>();
// Enqueue elements
        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);
// Dequeue elements
        int dequeuedElement1 = queue.dequeue(); // 10
        int dequeuedElement2 = queue.dequeue(); // 20
// Check if the queue is empty
        boolean isEmpty = queue.isEmpty(); // false
// Expected output
        System.out.println("Dequeued element 1: " + dequeuedElement1);
        System.out.println("Dequeued element 2: " + dequeuedElement2);
        System.out.println("Is the queue empty? " + isEmpty);
    }
}


