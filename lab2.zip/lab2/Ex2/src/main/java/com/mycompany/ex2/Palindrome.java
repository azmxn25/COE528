/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex2;

/**
 *
 * @author azman
 */
public class Palindrome {
    //Requires: Requires the string a
    //Modifies: Nothing
    //Effects: Returns true is the string is a palindrome and false if it is not
    public static boolean isPalindrome(String a) {
        if(a == null || a.equals("")){
            return false;
        }
        
        int start = 0;
        int end = a.length() - 1;

        while (end > start) {
            if (a.charAt(start) != a.charAt(end)) {
                return false;
            }
            start++;
            end--;
        }
    
    return true; 
    }
    public static void main(String[] args) {
        if(args.length == 1) {
            if (args[0].equals("1"))
                System.out.println(isPalindrome(null));
            else if (args[0].equals("2"))
                System.out.println(isPalindrome(""));
            else if (args[0].equals("3"))
                System.out.println(isPalindrome("deed"));
            else if (args[0].equals("4"))
                System.out.println(isPalindrome("abcd"));
        }
    }
}
