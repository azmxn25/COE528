/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex3;
import java.util.ArrayList;

/**
 *
 * @author azman
 */
public class AnagramChecker {
    //Requires: Requires two strings str1 and str2
    //Modifies: Nothing
    //Effects: Returns true is str1 and str2 is an anagram
    
    public static boolean areAnagrams(String str1, String str2){
        if(str1 == null || str1.equals("") || str2 == null || str2.equals("")){
            return false;
        }
        
        String checkstr1 = str1.replace(" ", "").toLowerCase();
        String checkstr2 = str2.replace(" ", "").toLowerCase();
        
        if (checkstr1.length() == checkstr2.length()){
            ArrayList<Character> letters = new ArrayList<Character>();
            
            for(int i = 0; i < checkstr1.length(); i++){
                letters.add(checkstr1.charAt(i));
            }
            
            for(int i = 0; i < checkstr2.length(); i++){
                for(int j = 0; j < letters.size(); j++){
                    if(letters.get(j) == checkstr2.charAt(i)){
                        letters.remove(j);
                    }
                }
            }
            
            if(letters.size() == 0){
                return true;
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }
    
    public static void main(String[] args){
        if(args.length == 2){
            System.out.println(args[0] + " "+ args[1] + " " + "Is Anagram:" + AnagramChecker.areAnagrams(args[0], args[1]));
        }
    }
}
