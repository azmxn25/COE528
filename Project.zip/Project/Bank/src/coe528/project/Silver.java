/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe528.project;

import java.io.IOException;

/**
 *
 * @author azman
 */

/*Silver: Customer has less than 10K in the bank account. Online purchases must be 50 or more and has to pay a 20 dollar
fee.*/
public class Silver extends CustomerLevel{
    @Override
    protected boolean onlinePurchase(double money, CustomerAccount customer) throws IOException{
        
        if(money >= 50 && customer.getBalance() >= (20 + money)){//If the balance is valid then purchase is made
            customer.setBalance(customer.getBalance() - money -20);
            System.out.println("The online purchase for the Silver account was successful, current balance is: " + customer.getBalance());
            updateLevel(customer);
            return true;
        }
        else{//If balance is not valid then purchase is not made
            System.out.println("The purchase for the Silver account was NOT successful");
            return false;
        }
    }
    @Override
    public String toString(){
        return "Silver";
    }
}
