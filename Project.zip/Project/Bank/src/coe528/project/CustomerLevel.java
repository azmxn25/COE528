/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe528.project;

import java.io.IOException;

/**
 *
 * @author azman
 */
public abstract class CustomerLevel {//Method for the customer level
    
    protected abstract boolean onlinePurchase(double money, CustomerAccount customer) throws IOException;//Signature of the onlinePurchase method
    
    /*There are three types of levels that a customer can have: silver, gold and platinum. Silver member has less than
    10,000 in the account. Gold member has between 10000 and 20000 in the account. Platinum member has 20000 or more in
    the account. 
    */
    
    public static void updateLevel(CustomerAccount customer){//Update the customer level based on balance
        
        if(customer.getBalance() < 10000){//Silver level since balance is less than 10K
            customer.setLevel(new Silver());
            System.out.println("Current level is SILVER");
        }
        else if(customer.getBalance() >= 10000 && customer.getBalance() < 20000){//Gold level since balance is between 10K and 20K
            customer.setLevel(new Gold());
            System.out.println("Current level is GOLD");
        }
        else{//Platinum level since balance is 20K or more
            customer.setLevel(new Platinum());
            System.out.println("Current level is PLATINUM");
        }
    }
    
    @Override
    public abstract String toString();
}

