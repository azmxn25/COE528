/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe528.project;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author azman
 */
public class ManagerAccount extends UserAccount{
    
    /*
      OVERVIEW: This class represents the account of the manager role. The ManagerAccount class is responsible 
    * for authenticating log in credentials, creating customer account files and deleting customer account files.
    * This class is immutable.
    * 
    * The Abstraction Function is:
    * AF(c)= an abstract Manager Account M where M.username is c.username and M.password is c.password
    *
    * The Rep Invariant is:
    * RI(c) = true if c.username == "admin" and c.password == "admin"
    *
    */
    
    public ManagerAccount(){//Constructor that sets the username and password for the manager
        /*
        EFFECT: Instantiates a ManagerAccount object with the username and password both as "admin".
        */
        username = "admin";
        password = "admin";
    } 
    
    public static boolean loginAuthenticate(String inputusername, String inputpassword){//Static method to check login credentails
        /*
        REQUIRES: inputusername & inputpassword to not be null
        EFFECTS: Returns true if the inputusername & inputpassword are the same as c.username and c.password for
        * a concrete ManagerAccount object c. Otherwise false.
        */
        return (inputusername.equals("admin") && inputpassword.equals("admin"));//return true if username and password is correct 
    }
    
    public boolean addCustomer(String newusername, String newpassword) throws IOException {//Method to add a customer
        /*
        REQUIRES: newusername & newpassword to not be null strings
        MODIFIES: The file "newusername.txt"
        EFFECTS: If a file with the name newusername.txt does not already exist in src/CustomerFiles,
        * creates a new file named newusername.txt in the src/CustomerFiles directory, writes the newpassword
        * on the first line and 100.0 on the second line, and returns true. If a file with the name
        * newusername.txt already exists, does not modify it and returns false.
        */
        File file = new File("C:\\Users\\azman\\OneDrive\\Desktop\\COE528\\Project\\Bank\\src\\CustomerFiles\\Names" + newusername + ".txt");
        if(file.exists()){
            System.out.println("Cannot add " + file + ", username");
            return false;      
        }
        else{
          file.createNewFile();
          FileWriter writer = new FileWriter(file);
          writer.write(newpassword + "\n" + "100.0");
          writer.close();
          System.out.println("File was successfully created in CustomerFiles directory " + file);
          return true;
        } 
    }
    
    public boolean deleteCustomer(String oldusername){//Method to delete a customer
        /*
        REQUIRES: oldusername to not be null
        MODIFIES: The file "oldnewusername.txt"
        EFFECTS: IIf a file does not exist with the name "oldusername.txt" in the src/CustomerFiles directory, 
        * then do not delete anything and return false. Otherwise, delete the file in the 
        * src/CustomerFiles/ directory that has the name "oldusername.txt"
        */
        File file = new File("C:\\Users\\azman\\OneDrive\\Desktop\\COE528\\Project\\Bank\\src\\CustomerFiles\\Names" + oldusername + ".txt");
        if(file.delete()){
            System.out.println(file + "was succesfully deleted.");
            return true;
        }
        else{
            System.out.println(file + "was not deleted.");
            return false;
        }
    }
    
    private boolean repOk(){
        /*
        EFFECT: Returns true is the rep invariant holds true for this object. Otherwise false.
        */
        if(username.equals("admin") && password.equals("admin")){
            return true;
        }
        else{
            return false;
        }
    }
    
    @Override
    public String toString(){
        /*
        EFFECT: Returns the abstract representation of the ManagerAccount as a string
        */
        return ("Account Username: " + username + ", Account Password: " + password);
    }
} 
