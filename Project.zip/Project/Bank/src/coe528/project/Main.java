package coe528.project;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import coe528.project.CustomerAccount;
import coe528.project.ManagerAccount;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;

/**
 *
 * @author azman
 */
public class Main extends Application {

    private Scene initialScene; //stores the homepage/home screen
    private ManagerAccount manager = new ManagerAccount(); //the manager object used by the app 

    @Override
    public void start(Stage primaryStage) {

        Button btnManager = new Button("Manager"); //buttons 
        Button btnCustomer = new Button("Customer");

        btnManager.setOnAction(e -> //action events for the buttons 
        {
            primaryStage.setScene(createManagerLog(primaryStage));
        });
        
        btnCustomer.setOnAction(e ->
        {
            primaryStage.setScene(createCustomerLog(primaryStage));
        });
        
         // Create a title label
        Label titleLabel = new Label("Sterling Bank of Canada");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

         // Create an HBox for the buttons and set alignment to center
        HBox buttons = new HBox(10);
        buttons.setAlignment(Pos.CENTER);
        buttons.getChildren().addAll(btnManager, btnCustomer);

        // Create a VBox to stack the title label on top and the buttons below
        VBox root = new VBox(10);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(50, 0, 0, 0)); // Add top padding to move the title up
        root.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, CornerRadii.EMPTY, Insets.EMPTY))); // Set light blue background
        root.getChildren().addAll(titleLabel, buttons);
        initialScene = new Scene(root, 500, 500);

  
         
        primaryStage.setMinWidth(500);	
        primaryStage.setMinHeight(500);
        primaryStage.setTitle("SterlingBank");
        primaryStage.setScene(initialScene);
        primaryStage.show();
    }

    private Scene createManagerLog(Stage primaryStage) {
        //create labels and text fields 
        Label lblUserName = new Label("Enter username: ");
        TextField txtUserName = new TextField();
        Label lblPassword = new Label("Enter password: ");
        TextField txtPassword = new TextField();

        Button btnLogin = new Button("Log In"); //create a login button 
        Button btnBack = new Button("Back"); //bank/logout button
        btnLogin.setOnAction(e -> 
        {
            if (ManagerAccount.loginAuthenticate(txtUserName.getText(), txtPassword.getText())) //go to manager screen is authenciated
            {
                primaryStage.setScene(createManagerScreen(primaryStage));
            }

        });

        btnBack.setOnAction(e -> primaryStage.setScene(initialScene)); //go back to main screen

        HBox UserName = new HBox(15); //just a bunch of boilerplate, setting up the GUI
        UserName.getChildren().addAll(lblUserName, txtUserName);
        HBox Password = new HBox(15);
        Password.getChildren().addAll(lblPassword, txtPassword);
        UserName.setAlignment(Pos.CENTER);
        Password.setAlignment(Pos.CENTER);
        VBox inputs = new VBox(20);
        inputs.getChildren().addAll(UserName, Password, btnLogin, btnBack);
        inputs.setAlignment(Pos.CENTER);
        

        StackPane root = new StackPane();
        root.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, CornerRadii.EMPTY, Insets.EMPTY))); // Set light blue background
        root.getChildren().addAll(inputs);

        return new Scene(root, 500, 500);

    }
    
    private Scene createCustomerLog(Stage primaryStage) {
        //create labels and text fields 
        Label lblUserName = new Label("Enter username: ");
        TextField txtUserName = new TextField();
        Label lblPassword = new Label("Enter password: ");
        TextField txtPassword = new TextField();

        Button btnLogin = new Button("Log In"); //create a login button 
        Button btnBack = new Button("Back");
        btnLogin.setOnAction(e -> //if authenticated, go to customer screen
        {
            try
            {
                if (CustomerAccount.loginAuthenticate(txtUserName.getText(), txtPassword.getText()))
                {   
                    primaryStage.setScene(createCustomerScreen(primaryStage, new CustomerAccount(new File("C:\\Users\\azman\\OneDrive\\Desktop\\COE528\\Project\\Bank\\src\\CustomerFiles\\Names" + txtUserName.getText() + ".txt"))));
                    System.out.println("Authenticated.");
                }
                else {
                    System.out.println("Not Authenticated");
                }
            } catch (FileNotFoundException ex)
            {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }

        });

        btnBack.setOnAction(e -> primaryStage.setScene(initialScene)); //go back

        HBox UserName = new HBox(15); //more boilerplate
        UserName.getChildren().addAll(lblUserName, txtUserName);
        HBox Password = new HBox(15);
        Password.getChildren().addAll(lblPassword, txtPassword);
        UserName.setAlignment(Pos.CENTER);
        Password.setAlignment(Pos.CENTER);
        VBox inputs = new VBox(20);
        inputs.getChildren().addAll(UserName, Password, btnLogin, btnBack);
        inputs.setAlignment(Pos.CENTER);

        StackPane root = new StackPane();
        root.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, CornerRadii.EMPTY, Insets.EMPTY))); // Set light blue background
        root.getChildren().addAll(inputs);

        return new Scene(root, 500, 500);
    }
    
    private Scene createManagerScreen(Stage primaryStage) {
        //labels and textfields
        Label lblCustomerUserName = new Label("Enter Username: ");
        TextField txtCustomerUserName = new TextField();
        Label lblCustomerPassword = new Label("Enter password: ");
        TextField txtCustomerPassword = new TextField();
        Label status = new Label(""); //empty by default but will be used to display any status updates

        Button btnCreate = new Button("Create Account"); //create account button 
        btnCreate.setOnAction(e -> {
            try
            {
                if(manager.addCustomer(txtCustomerUserName.getText(), txtCustomerPassword.getText())) { //if making account was sucessful
                        status.setText(txtCustomerUserName.getText() + " was added");
                }
                else {
                    status.setText(txtCustomerUserName.getText() + " could not be added");
                }
            } catch (IOException ex)
            {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
                
        });
        
        Button btnDelete = new Button("Delete Account"); //delete account from file 
        
        btnDelete.setOnAction(e -> {
            
            if(manager.deleteCustomer(txtCustomerUserName.getText())) {
                 status.setText(txtCustomerUserName.getText() + " was deleted"); //if deleted 
            }
            else {
                status.setText(txtCustomerUserName.getText() + " could not be deleted");//if not deleted
            }
            
        });
        Button btnBack = new Button("Log Out");
        btnBack.setOnAction(e -> primaryStage.setScene(initialScene)); //go back to main scene

        HBox UserName = new HBox(15);//boilerplate
        UserName.getChildren().addAll(lblCustomerUserName, txtCustomerUserName);
        UserName.setAlignment(Pos.CENTER);
        HBox Password = new HBox(15);
        Password.getChildren().addAll(lblCustomerPassword, txtCustomerPassword);
        Password.setAlignment(Pos.CENTER);
        HBox statusBox = new HBox(15);
        statusBox.getChildren().addAll(status);
        statusBox.setAlignment(Pos.CENTER);
        HBox button = new HBox(10);
        button.getChildren().addAll(btnCreate, btnDelete, btnBack);
        button.setAlignment(Pos.CENTER);
        VBox inputs = new VBox(5);
        inputs.getChildren().addAll(UserName, Password, statusBox, button);
        inputs.setAlignment(Pos.CENTER);
        

        StackPane root = new StackPane();
        root.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, CornerRadii.EMPTY, Insets.EMPTY))); // Set light blue background
        root.getChildren().addAll(inputs);

        return new Scene(root, 500, 500);

    }
    
    private Scene createCustomerScreen(Stage primaryStage, CustomerAccount customer) {
        //textfields and labels
        Label lblCustomerUserName = new Label("Customer username: " + customer.getUsername()); //label to display customer username
        Label lblLevel = new Label("Account Level: " + customer.getLevel().toString()); //label to display level
        Label lblBalance = new Label("Account Balance: " + Double.toString(customer.getBalance())); //label to display balance
        TextField moneyField = new TextField(); //field to get any inputs related to money from user
        Label status = new Label(""); //empty by default but will be used to display any status updates
        
        Button btnDeposit = new Button("Deposit"); //button declarations
        Button btnWithdraw = new Button("Withdraw");
        Button btnOnlinePurchase = new Button("Online Purchase");
        Button btnRefresh = new Button("Refresh");
        Button btnBack = new Button("Log Out");
        
        btnDeposit.setOnAction(e -> { //deposit money button 
            try
            {
                if (customer.depositMoney(Double.valueOf(moneyField.getText()))) {
                    status.setText("Successfully deposited into the bank account");
                   
                }
                else {
                    status.setText("Unable to deposit this amount.");
                }
            } catch (IOException ex)
            {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
            catch (Exception ep) {
                status.setText("Please enter a valid amount");
            }
        }) ;
        
        btnWithdraw.setOnAction(e -> {
            try
            {
                if(customer.withdrawMoney(Double.valueOf(moneyField.getText()))) {
                    status.setText("Successfully withdrew from the bank account");
                }
                else {
                    status.setText("Unable to withdraw this amount");
                }
            } catch (IOException ex)
            {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            } catch (Exception ep){
                status.setText("Please enter a valid amount");
            }
        });
        
        btnOnlinePurchase.setOnAction(e -> {
            try
            {
                if (customer.onlinePurchase(Double.valueOf(moneyField.getText()))) { //if was able to make the purchase
                    status.setText("Purchase was successful");
                   
                }
                else {
                    status.setText("Unable to purchase");
                }
            } catch (IOException ex)
            {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
            catch (Exception ep) {
                status.setText("Please enter a valid amount");
            }
        }) ;
        
         btnRefresh.setOnAction(e -> { //refresh the labels that display customer info
            lblCustomerUserName.setText("Customer Username: " + customer.getUsername());
            lblLevel.setText("Account Level: " + customer.getLevel().toString());
            lblBalance.setText("Account Balance: " + Double.toString(customer.getBalance()));
            status.setText("");
        }); 
        
        btnBack.setOnAction(e -> { 
            primaryStage.setScene(initialScene);
        } );
        
        
        VBox info = new VBox(5); //le boilerplate 
        info.getChildren().addAll(lblCustomerUserName, lblLevel, lblBalance);
        info.setAlignment(Pos.CENTER);
        VBox moneyInput = new VBox(2);
        moneyInput.getChildren().addAll(moneyField, status);
        moneyInput.setAlignment(Pos.CENTER);
        HBox topButtons = new HBox(2);
        topButtons.getChildren().addAll(btnDeposit, btnWithdraw, btnOnlinePurchase);
        topButtons.setAlignment(Pos.CENTER);
        HBox bottomButtons = new HBox(2);
        bottomButtons.getChildren().addAll(btnRefresh, btnBack);
        bottomButtons.setAlignment(Pos.CENTER);
        VBox allElements = new VBox(1);
        allElements.getChildren().addAll(info, moneyInput, topButtons, bottomButtons);
        allElements.setAlignment(Pos.CENTER);
        
        StackPane root = new StackPane();
        root.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, CornerRadii.EMPTY, Insets.EMPTY))); // Set light blue background
        root.getChildren().addAll(allElements);
        return new Scene(root, 500, 500);

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
