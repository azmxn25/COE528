/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe528.project;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author azman
 */
public class CustomerAccount extends UserAccount{
    
    private File accountFile;
    private double balance;
    private CustomerLevel level;
    
    public CustomerAccount(File customerFile)throws FileNotFoundException {
        this.accountFile = customerFile;
        Scanner reader = new Scanner(this.accountFile);
        
        this.username = this.accountFile.getName().replaceFirst("\\.txt$", ""); 
        this.password = reader.nextLine();
        this.balance = reader.nextDouble();
        CustomerLevel.updateLevel(this);
        reader.close();
    }
    
    private void updateFile() throws IOException {
        FileWriter writer = new FileWriter(this.accountFile);
        writer.write(password + "\n" + balance);
        writer.close();
    }
    
    public static boolean loginAuthenticate(String inputusername, String inputpassword) throws FileNotFoundException {
        File file = new File("C:\\Users\\azman\\OneDrive\\Desktop\\COE528\\Project\\Bank\\src\\CustomerFiles\\Names" + inputusername + ".txt");
        if(file.exists()){
            Scanner reader = new Scanner(file);
            if(reader.nextLine().equals(inputpassword)){
                System.out.println("Customer authenticated. username and password, " + inputusername + " and " + inputpassword + " is correct and file is " + file);
                return true;
            }
            else{
                System.out.println("Username exists as " + inputusername + ", but the password is not correct");
                return false;
            }
        }
        else{
            System.out.println("File for the username " + inputusername + " does not exist");
            return false;
        }
    }
    
    public boolean depositMoney(double money) throws IOException {
        if(money < 0){
            System.out.println("Please deposit a positive ammount");
            return false;
        }
        
        balance = balance + money;
        level.updateLevel(this);
        this.updateFile();
        System.out.println("Amount Deposited " + money + "successfully");
        return true;
    }
    
    public boolean withdrawMoney(double money) throws IOException {
        if(money < 0 || money > balance){
            System.out.println("Withdraw unsuccessfull");
            return false;
        }
        else{
            balance = balance - money;
            level.updateLevel(this);
            this.updateFile();
            System.out.println("Withdraw successful, current balance is: " + balance);
            return true;       
        }
    }
    
    public boolean onlinePurchase(double money) throws IOException {
        return (level.onlinePurchase(money, this));
    }
    
    public double getBalance(){
        return balance;
    }
    
    public void setBalance(double newBalance) throws IOException {
        this.balance = newBalance;
        level.updateLevel(this);
        this.updateFile();
    }
    
    public void setLevel(CustomerLevel level){
        this.level = level;
    }
    
    public CustomerLevel getLevel(){
        return level;
    }
    
    public String toString(){
        return(accountFile + ", " + username + ", " + password + ", " + balance + ", " + level);
    }
}
