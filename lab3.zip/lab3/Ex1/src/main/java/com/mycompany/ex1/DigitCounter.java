/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex1;

/**
 *
 * @author azman
 */
public class DigitCounter extends AbstractCounter{
    Odometer leftstart;
    
    public DigitCounter(Odometer leftstart) { //Odometer is linked with the left most digit
        this.leftstart = leftstart;
    }
    
}
