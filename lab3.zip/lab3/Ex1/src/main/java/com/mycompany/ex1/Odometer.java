/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex1;

/**
 *
 * @author azman
 */
public class Odometer implements Counter {
    int n;
    Counter digits [];//Array
    
    public Odometer(int n) {
        if (n < 1) {
            throw new IllegalArgumentException("Number of digits in odometer must be at least 1"); //throws exception is the number of digits is less than 1
        }
        digits = new Counter[n];  
        digits[0] = new DigitCounter(this); 
        if (n > 1) { 
            for (int i = 1; i < n; i++) { 
                digits[i] = new LinkedDigitCounter(digits[i-1]);  
            }

        }
    }
    
    public String count() {
        String countString = "";
        for (Counter i : digits) { //Gets the value and converts it into a string
            countString = countString + i.count();
        }
  
        return countString;
    }
    
    @Override
    public void increment() {
        digits[digits.length - 1].increment(); //increment the digits
    }
    @Override
    public void decrement() {
        digits[digits.length - 1].decrement(); //decrement the digits 
    }
    
    @Override
    public void reset() {
        for (Counter i : digits) { //Resets all the digits 
            i.reset(); 
        }
    }
    
    
    
}
