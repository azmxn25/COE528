/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex1;

/**
 *
 * @author azman
 */
public class AbstractCounter implements Counter{
    int value;
    
    public AbstractCounter(){
        value = 0;
    }
    
    public String count(){
        return Integer.toString(value);
    }
    
    public void increment(){
        if (value < 9)
            value = value + 1;
        else {
            value = 0;
        }
    }

    public void decrement(){
        if (value > 0)
            value = value - 1;
        else {
            value = 9;
        }
    }

    public void reset(){
        value = 0;
    }; 
}
